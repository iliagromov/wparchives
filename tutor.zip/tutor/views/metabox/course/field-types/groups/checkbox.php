
<label>
    <input type="checkbox" name="<?php echo esc_attr( $input_name ); ?>" value="1" <?php checked($input_value, '1'); ?> >
    <?php echo esc_attr( $label ); ?>
</label>
