
<label>
    <input type="checkbox" name="<?php esc_attr_e( $input_name ); ?>" value="1" <?php checked($input_value, '1'); ?> >
    <?php esc_html_e( $label ); ?>
</label>
